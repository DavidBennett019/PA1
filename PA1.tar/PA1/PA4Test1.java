import meggy.Meggy;

class PA4Test1 {
	public static void main(String[] args) {
		while(true){
			if(1 < 2){
				Meggy.toneStart(Meggy.Tone.A3, 50);
			}
		}
	}
}